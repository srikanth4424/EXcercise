import { TestBed } from '@angular/core/testing';

import { VsoftService } from './vsoft.service';

describe('VsoftService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: VsoftService = TestBed.get(VsoftService);
    expect(service).toBeTruthy();
  });
});
