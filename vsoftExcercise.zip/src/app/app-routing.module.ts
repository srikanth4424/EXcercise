import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ViewemployeeComponent } from './viewemployee/viewemployee.component';
import { ViewallComponent } from './viewall/viewall.component';

const routes: Routes = [
  {
    path: '', component: ViewallComponent
  },
  { path: 'viewEmployee', component: ViewemployeeComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
